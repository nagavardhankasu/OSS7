let myname : string ="rama";
let num : number = 35;
let emp = {"id":"1001","Ename":"Rama"}


function myFunction(n : any) :  string | number | undefined {
    if(typeof(n)=="number")
    return n*n;
    else if (typeof(n)=="string")
    return n.toUpperCase();
    else return undefined;
}


console.log(myFunction(myname));
console.log(myFunction(num));
console.log(myFunction(emp));