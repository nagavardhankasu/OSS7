let sal : number ;
sal = 3000
let ename : string ="Rama"

//Calculating PF 
let pf : number = (sal/100)*5

// Calculating Total Salafry
let tsal : number = sal+pf

console.log("Ename : " + ename + "    Totoal Salry  :" + tsal)