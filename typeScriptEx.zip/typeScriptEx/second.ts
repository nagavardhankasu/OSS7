let fname : string ="Unic";

let lname : string=" Solutions"


function MyString(f : string ,l: string ) t{
    console.log("Full Name :" + (f+l))
}


MyString(fname, lname);


