
class Employee
{
    Id: number ;
    Name : string;
    City : string 
    // constructor(i: number, nm : string, c : string){
    // this.Id= i; this.Name= nm; this.City= c
    // }
    Display(){
        console.log("ID : " + this.Id )
        console.log("Name : " + this.Name )
        console.log("City : " + this.City )
    }
}



let empObj : Employee
empObj = new Employee()

empObj.Id = 1001
empObj.Name="Rajesh"
empObj.City= "Bangloire"


empObj.Display()



let empObj2 : Employee = new Employee() 
empObj2.Id= 1003;
empObj2.Name="Ganga"
empObj2.City="Chennai"

empObj2.Display();

