// let ar : string[] =["Hyderabad","Banglore","Delhi","Pune"]


// console.log("Tot Number of Elements  : " + ar.length)
// // console.log( ar[0]);


// // for(let i: number = 0 ; i<ar.length; i++){
// //     console.log(ar[i]);
// // }


// ar.push("Mumbai")
// ar.push("Chennai")

// ar.forEach((item)=>{
//     console.log(item.toUpperCase())
// })


// ar.splice(4,1)

// console.log("----------------------------")

// ar.forEach((item)=>{
//     console.log(item.toUpperCase())
// })


let Employees : any[]=[];

Employees.push({"Id":"1001","Name":"Rakesh","Salary":3000})
Employees.push({"Id":"1002","Name":"Hitesh","Salary":3100})
Employees.push({"Id":"1003","Name":"Mahesh","Salary":3500})
Employees.push({"Id":"1004","Name":"Ramesh","Salary":3200})


Employees.forEach((emp)=>{

    console.log(emp.Id  + " | " + emp.Name+ " | "+ emp.Salary)
})



